using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class canvasManager : MonoBehaviour
{
    public static canvasManager Instance;
    [Header("Panels")]
    public GameObject winPanel;
    public GameObject LoosePanel;
    public GameObject gamepanel;
    public RectTransform coinReachPos;
    public ParticleControlScript pS;
    int levelNo = 0;
    int levelShowNo = 1;
    public TextMeshProUGUI levelText, coinText, CoinShopText, noText;
    public Transform shopParent;
    public Sprite[] charIcons;
    public int coins = 0;
    public int coinsNo = 0;

    public GameObject CoinBg;
    private void Awake()
    {
        if (!Instance)
            Instance = this;

    }
    private void Start()
    {
        levelNo = SceneManager.GetActiveScene().buildIndex;
        if (AudioManager.instance)
            AudioManager.instance.Play("bg");
        levelShowNo = PlayerPrefs.GetInt("levelshow", 1);
        levelText.text = "关卡 " + levelShowNo;
        coins = PlayerPrefs.GetInt("coins", 300);
        CoinUpdate();

    }

    public void Privacy()
    {
        Will_ToAndroid.Privacy();
    }
    public void MoreGame()
    {
        Will_ToAndroid.MoreGame();
    }
    // Update is called once per frame
    void Update()
    {

    }
    public void CoinUpdate()
    {
        coinText.text = coins.ToString();
        CoinShopText.text = coins.ToString();
        PlayerPrefs.SetInt("coins", coins);
    }
    public void RetryMethod()
    {
        Will_ToAndroid.ShowInter();
        SceneManager.LoadScene(levelNo);
    }

    public void RewardButton()
    {
        //int random = Random.Range(0, shopParent.childCount);
        //shopScript sScript = shopParent.GetChild(random).GetComponent<shopScript>();

        //if (!sScript.isUnlocked)
        //{
        //    sScript.BuyButton();
        //}
        //else
        //    RewardButton();
#if UNITY_ANDROID && !UNITY_EDITOR
        using (AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
  {
    using (AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity"))
     {
        jo.Call("ShowVideo","Coins");
     }
  } 
        
#endif

    }
    public void ShowAD()
    {
        Will_ToAndroid.ShowAd();
    }
    public void ShowInter()
    {
        Will_ToAndroid.ShowInter();
    }
    public void Reward()
    {
        coins += 150;
        CoinUpdate();
    }
    public void UnlockRandom()
    {
        if (coins >= 150)
        {
            int random = Random.Range(0, shopParent.childCount);
            shopScript sScript = shopParent.GetChild(random).GetComponent<shopScript>();

            if (!sScript.isUnlocked)
            {
                sScript.BuyButton();
            }
            else
            {
                UnlockRandom();
                //Debug.Log("已经全部解锁");
            }

            if (coins >= 150)
            {
                coins -= 150;
                PlayerPrefs.SetInt("coins", coins);
                CoinUpdate();
            }

        }
        else
        {

            Debug.Log("金币不足");
            CoinBg.SetActive(true);
            Invoke("dis", 1.2f);
        }

    }
    void dis()
    {
        CoinBg.SetActive(false);
    }
    public void NextLevel()
    {
        Will_ToAndroid.ShowInter();
        levelNo++;
        levelShowNo++;
        PlayerPrefs.SetInt("level", levelNo);
        PlayerPrefs.SetInt("levelshow", levelShowNo);

        SceneManager.LoadScene(levelNo);
    }
    public void FailMethod()
    {
        Will_ToAndroid.ShowAd();
        AudioManager.instance.Pause("bg");
        gamepanel.SetActive(false);
        LoosePanel.SetActive(true);
    }
    public void WinMethod()
    {
        Will_ToAndroid.ShowAd();
        AudioManager.instance.Pause("bg");
        pS.coinsCount = coinsNo;
        pS.PlayControlledParticles(new Vector2(Screen.width / 2, Screen.height / 2), coinReachPos);
        gamepanel.SetActive(false);
        winPanel.SetActive(true);
    }
    public void playButton()
    {
        Will_ToAndroid.ShowInter();
        GameManager.Instance.startGame = true;
    }



    public void loopmethod()
    {
        levelNo = 1;
        levelShowNo++;
        PlayerPrefs.SetInt("level", levelNo);
        PlayerPrefs.SetInt("levelshow", levelShowNo);

        SceneManager.LoadScene(levelNo);
    }
}

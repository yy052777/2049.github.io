﻿using UnityEngine;
using System.Collections;

public class Will_GameManager : MonoBehaviour
{

    public static Will_GameManager Instance;

    public bool isShenHeBao;
   

    void Awake()
    {


        if (Instance != null && Instance != this)
        {
          
            Destroy(this.gameObject);
            return;
        }
        else
        {
            transform.name = "Will_GameManager";
            Instance = this;
        }
        DontDestroyOnLoad(this.gameObject);

    }


}

using UnityEngine;
using System.Collections;

public class Will_ToAndroid
{

    //退出游戏的接口
    public static void ExitGame()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("退出游戏");
            Application.Quit();
        }
        else
        {
            ToAndroid("Exit");
        }

    }
    //显示广告的接口
    public static void ShowAd()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("广告");
        }
        else
        {
            ToAndroid("ShowAD");
        }
    }
    public static void Privacy()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("隐私政策");
        }
        else
        {
            ToAndroid("Privacy");
        }
    }
    public static void ShowInter()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("主界面（进入游戏）");
        }
        else
        {
            ToAndroid("ShowInter");
        }
    }
    //显示广告的接口
    public static void ShowNewAD()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("广告");
        }
        else
        {
            ToAndroid("ShowNewAD");
        }
    }

    public static void MoreGame()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("更多精彩");
        }
        else
        {
            ToAndroid("MoreGame");
        }
    }

    public static void ShowVideoAD()
    {
        if (Will_GameManager.Instance.isShenHeBao)
        {
            Debug.Log("视频广告");
        }
        else
        {
            ToAndroid("ShowVudioAD");
        }
    }

    //向Android层传参数
    static void ToAndroid(string msg)
    {

        if (Will_GameManager.Instance.isShenHeBao)
        {
            return;
        }
        else
        {
            string methodName = "UnityToAndroid";
            using (AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                using (AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity"))
                {
                    jo.Call(methodName, new object[] { msg });
                }
            }
        }


    }

}
